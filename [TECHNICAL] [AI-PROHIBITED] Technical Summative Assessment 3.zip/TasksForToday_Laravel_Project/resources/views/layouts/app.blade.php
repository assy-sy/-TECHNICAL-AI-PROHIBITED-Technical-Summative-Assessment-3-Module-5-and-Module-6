<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>@yield('title', 'Tasks for Today') | Task Manager</title>
<style>
:root{font-family:Inter,ui-sans-serif,system-ui,-apple-system,Segoe UI,Arial;color:#152238;background:#f4f7fb}
*{box-sizing:border-box}body{margin:0}header{background:#10243e;color:#fff}nav{max-width:1000px;margin:auto;display:flex;gap:10px;align-items:center;padding:18px 24px;flex-wrap:wrap}
.brand{font-weight:800;margin-right:auto;letter-spacing:.2px}nav a{color:#dbe5f3;text-decoration:none;padding:9px 12px;border-radius:8px;font-size:14px}nav a.active,nav a:hover{background:#28486d;color:#fff}
main{max-width:1000px;margin:44px auto;padding:0 24px}h1{font-size:clamp(28px,4vw,38px);margin:0 0 8px}p.muted{color:#607088;margin:0 0 25px}.card{background:#fff;border:1px solid #e2e9f1;border-radius:16px;padding:25px;box-shadow:0 8px 25px #16284108}
.table-wrap{overflow-x:auto}table{border-collapse:collapse;width:100%}th,td{text-align:left;padding:15px 12px;border-bottom:1px solid #e9eef4}th{font-size:12px;text-transform:uppercase;letter-spacing:.7px;color:#728095}tr:last-child td{border-bottom:0}
.pill{display:inline-block;background:#f5edd1;color:#815f14;padding:5px 10px;border-radius:999px;font-size:12px;font-weight:700}.pill.completed{background:#e1f4e7;color:#1e7044}.pill.progress{background:#e3eeff;color:#245e9b}
.empty{padding:35px;text-align:center;color:#67758a}.profile{display:grid;grid-template-columns:160px 1fr;gap:10px 20px}.profile dt{color:#687994}.profile dd{margin:0;font-weight:600;overflow-wrap:anywhere}footer{max-width:1000px;padding:24px;margin:0 auto;color:#728095;font-size:13px}@media(max-width:600px){.profile{grid-template-columns:1fr}.profile dd{margin-bottom:12px}}
</style></head><body><header><nav><span class="brand">✓ Tasks for Today</span>
<a href="{{ route('welcome') }}" class="{{ request()->routeIs('welcome') ? 'active' : '' }}">Today</a>
<a href="{{ route('tasks.index') }}" class="{{ request()->routeIs('tasks.index') ? 'active' : '' }}">Task List</a>
<a href="{{ route('profile') }}" class="{{ request()->routeIs('profile') ? 'active' : '' }}">Profile</a>
<a href="{{ route('about') }}" class="{{ request()->routeIs('about') ? 'active' : '' }}">About</a>
</nav></header><main>@yield('content')</main><footer>Tasks for Today | Laravel Laboratory Project</footer></body></html>
