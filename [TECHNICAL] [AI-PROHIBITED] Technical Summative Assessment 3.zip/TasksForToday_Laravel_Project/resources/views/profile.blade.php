@extends('layouts.app')
@section('title','Profile')
@section('content')
<h1>User Profile</h1><p class="muted">The single profile stored in the users database table.</p>
<div class="card">@if($user)
<dl class="profile"><dt>Full name</dt><dd>{{ $user->full_name }}</dd>
<dt>Username</dt><dd>{{ $user->username }}</dd><dt>Email address</dt><dd>{{ $user->email }}</dd></dl>
@else<p>No user record was found. Run the database seeder.</p>@endif</div>
@endsection
