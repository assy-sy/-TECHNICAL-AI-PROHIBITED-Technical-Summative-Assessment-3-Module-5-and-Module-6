@extends('layouts.app')
@section('title','About')
@section('content')
<h1>About the Project</h1><p class="muted">Task management application built with Laravel and the MVC pattern.</p>
<div class="card"><h2>Developer</h2><p><strong>Name:</strong> [REPLACE WITH YOUR FULL NAME]</p>
<p><strong>Program / Section:</strong> [REPLACE WITH YOUR PROGRAM AND SECTION]</p>
<p><strong>Course:</strong> IT0049 - Web System Technologies</p>
<p>This activity demonstrates Laravel routes, controllers, Blade views, Eloquent models, database migrations, and seeders.</p></div>
@endsection
