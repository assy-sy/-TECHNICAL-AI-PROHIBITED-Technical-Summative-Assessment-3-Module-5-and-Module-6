@extends('layouts.app')
@section('title','Task List')
@section('content')
<h1>All Tasks</h1><p class="muted">Complete list of tasks, ordered by date from earliest to latest.</p>
<div class="card"><h2>{{ $tasks->count() }} total tasks</h2>
@if($tasks->isEmpty())<div class="empty">No tasks found.</div>@else
<div class="table-wrap"><table><thead><tr><th>Task</th><th>Status</th><th>Scheduled date</th></tr></thead><tbody>
@foreach($tasks as $task)<tr><td>{{ $task->title }}</td><td><span class="pill {{ $task->status === 'completed' ? 'completed' : ($task->status === 'in progress' ? 'progress' : '') }}">{{ ucfirst($task->status) }}</span></td><td>{{ $task->task_date->format('M d, Y') }}</td></tr>@endforeach
</tbody></table></div>@endif</div>
@endsection
