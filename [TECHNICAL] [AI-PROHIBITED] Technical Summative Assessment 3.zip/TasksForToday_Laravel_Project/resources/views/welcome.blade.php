@extends('layouts.app')
@section('title','Today')
@section('content')
<h1>Today's Tasks</h1><p class="muted">{{ today()->format('l, F j, Y') }} · Your tasks scheduled for today</p>
<div class="card"><h2>{{ $tasks->count() }} {{ \Illuminate\Support\Str::plural('task', $tasks->count()) }} for today</h2>
@if($tasks->isEmpty())<div class="empty">No tasks scheduled for today.</div>
@else<div class="table-wrap"><table><thead><tr><th>Task</th><th>Status</th><th>Date</th></tr></thead><tbody>
@foreach($tasks as $task)<tr><td>{{ $task->title }}</td><td><span class="pill {{ $task->status === 'completed' ? 'completed' : ($task->status === 'in progress' ? 'progress' : '') }}">{{ ucfirst($task->status) }}</span></td><td>{{ $task->task_date->format('M d, Y') }}</td></tr>@endforeach
</tbody></table></div>@endif</div>
@endsection
