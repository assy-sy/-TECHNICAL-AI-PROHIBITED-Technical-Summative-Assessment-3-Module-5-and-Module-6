<?php
namespace App\Http\Controllers;
use App\Models\Task;
use App\Models\User;
use Illuminate\Contracts\View\View;
class PageController extends Controller
{
    public function welcome(): View
    {
        $tasks = Task::query()->whereDate('task_date', today())->orderBy('id')->get();
        return view('welcome', compact('tasks'));
    }
    public function tasks(): View
    {
        $tasks = Task::query()->orderBy('task_date')->orderBy('id')->get();
        return view('tasks', compact('tasks'));
    }
    public function profile(): View
    {
        $user = User::query()->first();
        return view('profile', compact('user'));
    }
}
