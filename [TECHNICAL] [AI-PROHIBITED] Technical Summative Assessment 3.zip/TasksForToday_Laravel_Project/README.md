# Tasks for Today | Laravel Laboratory Activity

A Laravel 12 web application implementing four pages, a Task Eloquent model, a User Eloquent model, SQLite migrations, and a sample-data seeder.

## System requirements
- PHP 8.2+ with SQLite / PDO SQLite extensions
- Composer 2
- Local terminal (or a Laravel-compatible hosting provider)

## Local installation

1. Open a terminal in the project folder.
2. Install dependencies: `composer install`
3. Copy environment configuration: `cp .env.example .env` (Windows PowerShell: `Copy-Item .env.example .env`).
4. Generate application key: `php artisan key:generate`
5. Create empty `database/database.sqlite` file (Windows PowerShell: `New-Item database/database.sqlite -ItemType File`).
6. Run migrations and seed sample records: `php artisan migrate:fresh --seed`
7. Run the app: `php artisan serve`
8. Open http://127.0.0.1:8000.

If `composer install` reports missing PHP extensions, enable them in your `php.ini` first. Never put your real `.env` or passwords on GitHub.

## Routes
| URL | Function |
| --- | --- |
| `/` | Today's tasks only (`whereDate('task_date', today())`) |
| `/tasks` | All tasks sorted by task date ascending |
| `/profile` | First / single user record |
| `/about` | Developer description (static page) |

## Data

**tasks:** id, title, status (default `pending`), task_date, created_at, updated_at.
**users:** id, username (unique), full_name, email (unique), email_verified_at, password, remember_token, created_at, updated_at.

`DatabaseSeeder` inserts **9** tasks spanning yesterday, today, tomorrow and the following day, plus **1** sample user. Dates are calculated dynamically so the Welcome page still displays today's tasks on the date you run the seeder.

## Tests

After installing Composer dependencies run: `php artisan test`.

## Before submission

- [ ] Replace developer placeholders in `resources/views/about.blade.php`.
- [ ] Replace sample profile fields in `database/seeders/DatabaseSeeder.php`; re-run `php artisan migrate:fresh --seed` locally.
- [ ] Compare migrations against your **original TSA1 schema**, which was not supplied with this project.
- [ ] Test the site locally on the date of submission.
- [ ] Commit the source to your own GitHub repository, not the vendor folder or `.env`.
- [ ] Deploy to a live PHP/Laravel-compatible host, set production environment variables and run migrations / seeding there.
- [ ] Add the working GitHub and hosting URLs to your submission.

## Deployment note

The web document root must point to the Laravel `public/` directory. Never use the development server as a public production host. Choose the host's documented Laravel deployment procedure. The SQLite database must have persistent writable storage.

## Notes and limitations

This is an independently authored Laravel project template. Composer/vendor dependencies are not bundled. It has been PHP-syntax checked where a PHP runtime was available, but cannot be described as end-to-end tested until Composer dependencies are installed and the app is launched. Original TSA1 project/schema, real developer identity, GitHub access and hosting access were not supplied.
