<?php
namespace Database\Seeders;
use App\Models\Task;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
class DatabaseSeeder extends Seeder
{
 public function run(): void
 {
   User::query()->create([
     'username' => 'student_developer', 'full_name' => 'Student Developer',
     'email' => 'student@example.test', 'password' => Hash::make('change-me-before-production'),
   ]);
   $data = [
     ['Review Laravel routing','completed',today()->subDay()],
     ['Organize project folders','completed',today()->subDay()],
     ['Check migration structure','pending',today()],
     ['Finish Eloquent model setup','in progress',today()],
     ['Test Welcome page date filter','pending',today()],
     ['Verify Task List page','pending',today()],
     ['Write README documentation','pending',today()->addDay()],
     ['Review deployment settings','pending',today()->addDay()],
     ['Submit project links','pending',today()->addDays(2)],
   ];
   foreach ($data as [$title,$status,$date]) {
     Task::query()->create(['title'=>$title,'status'=>$status,'task_date'=>$date->toDateString()]);
   }
 }
}
