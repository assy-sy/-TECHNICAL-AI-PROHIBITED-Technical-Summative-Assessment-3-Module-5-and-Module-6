<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PageController;
Route::get('/', [PageController::class, 'welcome'])->name('welcome');
Route::get('/tasks', [PageController::class, 'tasks'])->name('tasks.index');
Route::get('/profile', [PageController::class, 'profile'])->name('profile');
Route::view('/about', 'about')->name('about');
