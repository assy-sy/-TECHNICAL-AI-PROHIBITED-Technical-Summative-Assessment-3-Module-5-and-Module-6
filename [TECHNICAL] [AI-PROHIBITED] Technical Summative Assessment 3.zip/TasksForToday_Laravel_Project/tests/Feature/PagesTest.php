<?php
namespace Tests\Feature;
use App\Models\Task;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
class PagesTest extends TestCase
{
 use RefreshDatabase;
 public function test_welcome_only_shows_todays_tasks(): void
 {
   Task::create(['title'=>'Shown today','task_date'=>today()->toDateString()]);
   Task::create(['title'=>'Hidden tomorrow','task_date'=>today()->addDay()->toDateString()]);
   $this->get('/')->assertOk()->assertSee('Shown today')->assertDontSee('Hidden tomorrow');
 }
 public function test_all_tasks_are_shown_in_date_order(): void
 {
   Task::create(['title'=>'Later task','task_date'=>today()->addDay()->toDateString()]);
   Task::create(['title'=>'Earlier task','task_date'=>today()->subDay()->toDateString()]);
   $response=$this->get('/tasks')->assertOk()->assertSee('Later task')->assertSee('Earlier task');
   $this->assertTrue(strpos($response->getContent(),'Earlier task') < strpos($response->getContent(),'Later task'));
 }
 public function test_profile_displays_user(): void
 {
   User::create(['username'=>'example','full_name'=>'Example Student','email'=>'example@example.test']);
   $this->get('/profile')->assertOk()->assertSee('Example Student');
 }
 public function test_about_page_loads(): void { $this->get('/about')->assertOk(); }
}
